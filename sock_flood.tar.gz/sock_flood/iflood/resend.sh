make clean
make
sz iflood
md5sum iflood
