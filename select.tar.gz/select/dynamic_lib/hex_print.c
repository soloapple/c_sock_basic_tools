/***************************************************************************************
 *   Copyright (C), 2016, X Co., Ltd.
 *
 *    Filename: hex_print.c
 * Description: 
 *     Version: 1.0
 *     Created: soloapple   08/01/16 16:33:47
 *    Revision: none
 *
 *     History: <author>   <time>    <version >         <desc>
 *              soloapple   08/01/16                  build this moudle  
 ***************************************************************************************/

#include "hex_print.h"
/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  hex_print
 *  Description:  
 * =====================================================================================
 */
char *	
hex_print ( char *src_string )
{
	printf ( "src:%s\n", src_string );
	return NULL;
}		/* -----  end of function hex_print  ----- */
