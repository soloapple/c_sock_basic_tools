/***************************************************************************************
 *   Copyright (C), 2016, X Co., Ltd.
 *   
 *    Filename: cut_false_sharing.h
 * Description: 
 *     Version: 1.0
 *     Created: soloapple   09/02/16 02:53:12
 *    Revision: none
 *      
 *     History: <author>   <time>    <version >         <desc>
 *              soloapple   09/02/16                  build this moudle
 ***************************************************************************************/
#include "../include/common.h"
