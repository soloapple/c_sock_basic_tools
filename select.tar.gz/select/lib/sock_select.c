/***************************************************************************************
 *   Copyright (C), 2016, X Co., Ltd.
 *
 *    Filename: sock_select.c
 * Description: all select function of socket
 *     Version: 1.0
 *     Created: soloapple   07/21/16 22:27:02
 *    Revision: none
 *
 *     History: <author>   <time>    <version >         <desc>
 *              soloapple   07/21/16                  build this moudle  
 ***************************************************************************************/
#include "sock_select.h"

/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  select_debug
 *  Description:  
 * =====================================================================================
 */
	void
select_debug ( )
{
	printf ( "select debug\n" );
	return ;
}		/* -----  end of function select_debug  ----- */
