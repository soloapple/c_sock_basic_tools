/***************************************************************************************
 *   Copyright (C), 2016, X Co., Ltd.
 *   
 *    Filename: sock_epoll.h
 * Description: 
 *     Version: 1.0
 *     Created: soloapple   08/01/16 13:23:37
 *    Revision: none
 *      
 *     History: <author>   <time>    <version >         <desc>
 *              soloapple   08/01/16                  build this moudle
 ***************************************************************************************/

#include "../include/common.h"

void epoll_debug();
