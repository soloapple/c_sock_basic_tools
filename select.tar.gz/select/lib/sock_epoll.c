/***************************************************************************************
 *   Copyright (C), 2016, X Co., Ltd.
 *
 *    Filename: sock_epoll.c
 * Description: all epoll functions
 *     Version: 1.0
 *     Created: soloapple   07/21/16 22:23:35
 *    Revision: none
 *
 *     History: <author>   <time>    <version >         <desc>
 *              soloapple   07/21/16                  build this moudle  
 ***************************************************************************************/

#include "sock_epoll.h"
/* 
 * ===  FUNCTION  ======================================================================
 *         Name:  epoll_debug
 *  Description:  
 * =====================================================================================
 */
	void
epoll_debug (  )
{
	printf ( "epoll debug file\n" );
	return ;
}		/* -----  end of function epoll_debug.c  ----- */


