/***************************************************************************************
 *   Copyright (C), 2016, X Co., Ltd.
 *   
 *    Filename: msg_key.h
 * Description: 
 *     Version: 1.0
 *     Created: soloapple   08/26/16 18:28:34
 *    Revision: none
 *      
 *     History: <author>   <time>    <version >         <desc>
 *              soloapple   08/26/16                  build this moudle
 ***************************************************************************************/

#ifndef  msg_key_INCLUDE
#define  msg_key_INCLUDE

#include "../include/common.h"

#endif   /* ----- #ifndef msg_key_INC  ----- */
