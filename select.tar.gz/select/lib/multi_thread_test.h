/***************************************************************************************
 *   Copyright (C), 2016, X Co., Ltd.
 *   
 *    Filename: multi_thread_test.h
 * Description: 
 *     Version: 1.0
 *     Created: soloapple   09/02/16 00:19:28
 *    Revision: none
 *      
 *     History: <author>   <time>    <version >         <desc>
 *              soloapple   09/02/16                  build this moudle
 ***************************************************************************************/

#include "../include/common.h"


#include <pthread.h>
