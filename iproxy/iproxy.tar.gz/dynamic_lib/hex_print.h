/***************************************************************************************
 *   Copyright (C), 2016, X Co., Ltd.
 *   
 *    Filename: hex_print.h
 * Description: 
 *     Version: 1.0
 *     Created: soloapple   08/01/16 16:35:51
 *    Revision: none
 *      
 *     History: <author>   <time>    <version >         <desc>
 *              soloapple   08/01/16                  build this moudle
 ***************************************************************************************/

#include "../include/common.h"
char *hex_print(char *src_string);
